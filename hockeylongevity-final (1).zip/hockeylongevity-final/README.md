# HockeyLongevity AI 🏒

**Coach IA personnel pour Stéphane - Joueur de hockey 46 ans avec arthrose**

## 🎯 Fonctionnalités

- **Daily Check-in** : Évalue ton sommeil, énergie et douleur chaque matin
- **Cerveau IA intelligent** : Génère des workouts adaptés à ton état
- **Matrice Rouge/Orange/Vert** : Protection automatique selon ta condition
- **Mémoire persistante** : Historique complet de tes check-ins
- **Spécifique à TON profil** :
  - Hernie L4-L5
  - Arthrite modérée hanches + dos
  - Travail de maçonnerie 60h/semaine
  - Matchs vendredi et dimanche soir

## 🚀 Déploiement sur Vercel (5 minutes)

### Étape 1 : Créer un compte GitHub (si pas déjà fait)
1. Va sur https://github.com
2. Crée un compte gratuit

### Étape 2 : Créer un repository
1. Clique sur "New repository"
2. Nom : `hockeylongevity`
3. Public ou Private (ton choix)
4. Clique "Create repository"

### Étape 3 : Upload les fichiers
Option A - Via Git :
```bash
cd hockeylongevity
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TON_USERNAME/hockeylongevity.git
git push -u origin main
```

### Étape 4 : Déployer sur Vercel
1. Va sur https://vercel.com
2. Connecte-toi avec GitHub
3. Clique "Add New Project"
4. Sélectionne ton repo `hockeylongevity`
5. Clique "Deploy"
6. Attends 1-2 minutes... C'est en ligne! 🎉

### Étape 5 : Installer sur ton iPhone
1. Ouvre Safari et va sur ton URL Vercel
2. Clique sur l'icône "Partager" (carré avec flèche)
3. Clique "Sur l'écran d'accueil"
4. L'app est maintenant installée comme une vraie app!

## ⚙️ Configuration de l'IA

Sans clé API : Utilise des workouts pré-définis (fonctionne bien!)
Avec clé API : L'IA génère des workouts 100% personnalisés

Pour activer l'IA complète :
1. Va sur https://platform.openai.com/api-keys
2. Crée une nouvelle clé API
3. Dans l'app, va dans Paramètres
4. Entre ta clé API

## 🧠 Comment l'IA pense

### Scénario ROUGE (Douleur ≥ 4/10)
- Protection totale, zéro impact

### Scénario ORANGE (Fatigué ou mal dormi)
- Récupération active, cardio léger

### Scénario VERT (Bonne condition)
- Entraînement complet, force fonctionnelle

## 🔧 Développement local

```bash
npm install
npm run dev
```

---
**Built with ❤️ for Stéphane**
