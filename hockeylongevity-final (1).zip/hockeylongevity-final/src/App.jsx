import { useState, useEffect } from 'react';
import { 
  Activity, Settings as SettingsIcon, Calendar, User,
  Menu, X
} from 'lucide-react';
import DailyCheckIn from './components/DailyCheckIn';
import WorkoutDisplay from './components/WorkoutDisplay';
import Settings from './components/Settings';
import History from './components/History';
import { generateWorkout } from './lib/api';
import { 
  saveCheckIn, saveWorkout, markWorkoutComplete, 
  getTodayCheckIn, getProfile, saveProfile 
} from './lib/storage';
import { STEPHANE_PROFILE } from './lib/coachBrain';

function App() {
  const [currentView, setCurrentView] = useState('checkin'); // checkin, workout, settings, history
  const [loading, setLoading] = useState(false);
  const [workout, setWorkout] = useState(null);
  const [currentCheckIn, setCurrentCheckIn] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  
  useEffect(() => {
    // Initialize profile if not exists
    if (!getProfile()) {
      saveProfile(STEPHANE_PROFILE);
    }
    
    // Check if already did check-in today
    const todayCheckIn = getTodayCheckIn();
    if (todayCheckIn) {
      setCurrentCheckIn(todayCheckIn);
    }
  }, []);
  
  const handleCheckInSubmit = async (checkInData) => {
    setLoading(true);
    
    try {
      // Save check-in
      const savedCheckIn = saveCheckIn(checkInData);
      setCurrentCheckIn(savedCheckIn);
      
      // Generate workout
      const generatedWorkout = await generateWorkout(checkInData);
      
      // Save workout
      saveWorkout(generatedWorkout, savedCheckIn);
      
      setWorkout(generatedWorkout);
      setCurrentView('workout');
    } catch (error) {
      console.error('Error:', error);
      alert('Erreur lors de la génération du workout. Réessaie.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleWorkoutComplete = (feedback) => {
    if (workout?.id) {
      markWorkoutComplete(workout.id, feedback);
    }
    setCurrentView('checkin');
    setWorkout(null);
  };
  
  const renderView = () => {
    switch (currentView) {
      case 'workout':
        return (
          <WorkoutDisplay 
            workout={workout}
            onComplete={handleWorkoutComplete}
            onBack={() => setCurrentView('checkin')}
          />
        );
      case 'settings':
        return <Settings onBack={() => setCurrentView('checkin')} />;
      case 'history':
        return <History onBack={() => setCurrentView('checkin')} />;
      default:
        return (
          <DailyCheckIn 
            onSubmit={handleCheckInSubmit}
            loading={loading}
          />
        );
    }
  };
  
  return (
    <div className="min-h-screen bg-dark-900">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-dark-600">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ice-500 to-ice-700 flex items-center justify-center">
              <span className="text-xl">🏒</span>
            </div>
            <div>
              <h1 className="font-display text-lg font-bold text-white leading-tight">
                HockeyLongevity
              </h1>
              <p className="text-xs text-ice-400">AI Coach</p>
            </div>
          </div>
          
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 rounded-lg hover:bg-dark-700 transition-colors"
          >
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
        
        {/* Dropdown Menu */}
        {menuOpen && (
          <div className="absolute top-full left-0 right-0 glass border-b border-dark-600 animate-fade-in-up">
            <div className="max-w-lg mx-auto p-4 space-y-2">
              <button
                onClick={() => { setCurrentView('checkin'); setMenuOpen(false); }}
                className={`w-full p-3 rounded-xl flex items-center gap-3 transition-colors ${
                  currentView === 'checkin' ? 'bg-ice-500/20 text-ice-400' : 'hover:bg-dark-700 text-white'
                }`}
              >
                <Activity className="w-5 h-5" />
                <span className="font-semibold">Check-in du jour</span>
              </button>
              
              <button
                onClick={() => { setCurrentView('history'); setMenuOpen(false); }}
                className={`w-full p-3 rounded-xl flex items-center gap-3 transition-colors ${
                  currentView === 'history' ? 'bg-ice-500/20 text-ice-400' : 'hover:bg-dark-700 text-white'
                }`}
              >
                <Calendar className="w-5 h-5" />
                <span className="font-semibold">Historique</span>
              </button>
              
              <button
                onClick={() => { setCurrentView('settings'); setMenuOpen(false); }}
                className={`w-full p-3 rounded-xl flex items-center gap-3 transition-colors ${
                  currentView === 'settings' ? 'bg-ice-500/20 text-ice-400' : 'hover:bg-dark-700 text-white'
                }`}
              >
                <SettingsIcon className="w-5 h-5" />
                <span className="font-semibold">Paramètres</span>
              </button>
            </div>
          </div>
        )}
      </header>
      
      {/* Main Content */}
      <main className="max-w-lg mx-auto px-4 py-6 pb-24">
        {renderView()}
      </main>
      
      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 glass border-t border-dark-600 safe-area-bottom">
        <div className="max-w-lg mx-auto px-4 py-2 flex justify-around">
          <NavButton 
            icon={<Activity className="w-6 h-6" />}
            label="Check-in"
            active={currentView === 'checkin'}
            onClick={() => setCurrentView('checkin')}
          />
          <NavButton 
            icon={<Calendar className="w-6 h-6" />}
            label="Historique"
            active={currentView === 'history'}
            onClick={() => setCurrentView('history')}
          />
          <NavButton 
            icon={<SettingsIcon className="w-6 h-6" />}
            label="Paramètres"
            active={currentView === 'settings'}
            onClick={() => setCurrentView('settings')}
          />
        </div>
      </nav>
      
      {/* Click outside to close menu */}
      {menuOpen && (
        <div 
          className="fixed inset-0 z-40"
          onClick={() => setMenuOpen(false)}
        />
      )}
    </div>
  );
}

function NavButton({ icon, label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-colors ${
        active 
          ? 'text-ice-400' 
          : 'text-gray-500 hover:text-gray-300'
      }`}
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

export default App;
