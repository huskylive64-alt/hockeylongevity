import { useState } from 'react';
import { 
  Play, Pause, RotateCcw, Check, ChevronDown, ChevronUp,
  AlertTriangle, Target, Heart, Dumbbell, Wind
} from 'lucide-react';

export default function WorkoutDisplay({ workout, onComplete, onBack }) {
  const [expandedSection, setExpandedSection] = useState('main');
  const [timer, setTimer] = useState(null);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [completedExercises, setCompletedExercises] = useState(new Set());
  
  const startTimer = (seconds) => {
    setTimerSeconds(seconds);
    setTimerRunning(true);
    
    const interval = setInterval(() => {
      setTimerSeconds(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setTimerRunning(false);
          // Vibrate if supported
          if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    setTimer(interval);
  };
  
  const stopTimer = () => {
    if (timer) clearInterval(timer);
    setTimerRunning(false);
  };
  
  const resetTimer = () => {
    stopTimer();
    setTimerSeconds(0);
  };
  
  const toggleExercise = (exerciseId) => {
    setCompletedExercises(prev => {
      const newSet = new Set(prev);
      if (newSet.has(exerciseId)) {
        newSet.delete(exerciseId);
      } else {
        newSet.add(exerciseId);
      }
      return newSet;
    });
  };
  
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  const getScenarioStyles = () => {
    switch (workout.scenario) {
      case 'ROUGE':
        return {
          bg: 'bg-red-gradient',
          border: 'border-alert-red/30',
          text: 'text-alert-red',
          badge: 'bg-alert-red/20'
        };
      case 'ORANGE':
        return {
          bg: 'bg-orange-gradient',
          border: 'border-alert-orange/30',
          text: 'text-alert-orange',
          badge: 'bg-alert-orange/20'
        };
      default:
        return {
          bg: 'bg-green-gradient',
          border: 'border-alert-green/30',
          text: 'text-alert-green',
          badge: 'bg-alert-green/20'
        };
    }
  };
  
  const styles = getScenarioStyles();
  
  const totalExercises = 
    (workout.workout?.warmup?.length || 0) + 
    (workout.workout?.main?.length || 0) + 
    (workout.workout?.cooldown?.length || 0);
  
  const progress = (completedExercises.size / totalExercises) * 100;
  
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Verdict Header */}
      <div className={`glass rounded-2xl p-6 ${styles.border} border-2`}>
        <div className="flex items-start gap-4">
          <div className={`w-16 h-16 rounded-xl ${styles.bg} flex items-center justify-center flex-shrink-0`}>
            <span className="text-3xl">
              {workout.scenario === 'ROUGE' ? '🛡️' : 
               workout.scenario === 'ORANGE' ? '🔋' : '⚡'}
            </span>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className={`px-3 py-1 rounded-full text-sm font-semibold ${styles.badge} ${styles.text}`}>
                {workout.scenario}
              </span>
              <span className="text-gray-400 text-sm">
                Battle Readiness: {workout.battleReadiness}%
              </span>
            </div>
            <p className="text-xl font-display text-white leading-tight">
              {workout.verdict}
            </p>
          </div>
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="glass rounded-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-400">Progression</span>
          <span className="text-sm font-semibold text-ice-400">
            {completedExercises.size}/{totalExercises}
          </span>
        </div>
        <div className="h-2 bg-dark-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-ice-500 to-ice-400 transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
      
      {/* Timer */}
      {timerSeconds > 0 && (
        <div className="glass rounded-2xl p-6 text-center animate-fade-in-up">
          <p className="text-sm text-gray-400 mb-2">REPOS</p>
          <p className={`text-6xl font-display font-bold ${timerRunning ? 'text-ice-400' : 'text-alert-green'}`}>
            {formatTime(timerSeconds)}
          </p>
          <div className="flex justify-center gap-4 mt-4">
            {timerRunning ? (
              <button 
                onClick={stopTimer}
                className="p-3 rounded-full bg-dark-600 text-white hover:bg-dark-500 transition-colors"
              >
                <Pause className="w-6 h-6" />
              </button>
            ) : (
              <button 
                onClick={() => startTimer(timerSeconds)}
                className="p-3 rounded-full bg-ice-500 text-dark-900 hover:bg-ice-400 transition-colors"
              >
                <Play className="w-6 h-6" />
              </button>
            )}
            <button 
              onClick={resetTimer}
              className="p-3 rounded-full bg-dark-600 text-white hover:bg-dark-500 transition-colors"
            >
              <RotateCcw className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}
      
      {/* Warmup Section */}
      {workout.workout?.warmup && (
        <ExerciseSection
          title="Échauffement"
          icon={<Wind className="w-5 h-5" />}
          exercises={workout.workout.warmup}
          expanded={expandedSection === 'warmup'}
          onToggle={() => setExpandedSection(expandedSection === 'warmup' ? null : 'warmup')}
          completedExercises={completedExercises}
          onToggleExercise={toggleExercise}
          onStartTimer={startTimer}
          sectionPrefix="warmup"
        />
      )}
      
      {/* Main Section */}
      {workout.workout?.main && (
        <ExerciseSection
          title="Entraînement Principal"
          icon={<Dumbbell className="w-5 h-5" />}
          exercises={workout.workout.main}
          expanded={expandedSection === 'main'}
          onToggle={() => setExpandedSection(expandedSection === 'main' ? null : 'main')}
          completedExercises={completedExercises}
          onToggleExercise={toggleExercise}
          onStartTimer={startTimer}
          sectionPrefix="main"
          isMain
        />
      )}
      
      {/* Cooldown Section */}
      {workout.workout?.cooldown && (
        <ExerciseSection
          title="Retour au calme"
          icon={<Heart className="w-5 h-5" />}
          exercises={workout.workout.cooldown}
          expanded={expandedSection === 'cooldown'}
          onToggle={() => setExpandedSection(expandedSection === 'cooldown' ? null : 'cooldown')}
          completedExercises={completedExercises}
          onToggleExercise={toggleExercise}
          onStartTimer={startTimer}
          sectionPrefix="cooldown"
        />
      )}
      
      {/* Hockey Tip */}
      {workout.hockeyTip && (
        <div className="glass rounded-2xl p-5 border border-ice-500/20">
          <div className="flex items-start gap-3">
            <Target className="w-6 h-6 text-ice-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-ice-400 font-semibold mb-1">CONSEIL HOCKEY</p>
              <p className="text-white">{workout.hockeyTip}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Recovery Focus */}
      {workout.recoveryFocus && (
        <div className="glass rounded-2xl p-5 border border-alert-green/20">
          <div className="flex items-start gap-3">
            <Heart className="w-6 h-6 text-alert-green flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-alert-green font-semibold mb-1">RÉCUPÉRATION</p>
              <p className="text-white">{workout.recoveryFocus}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Warnings */}
      {workout.warnings && workout.warnings.length > 0 && (
        <div className="glass rounded-2xl p-5 border border-alert-red/30 bg-red-gradient">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-alert-red flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-alert-red font-semibold mb-2">ATTENTION</p>
              <ul className="space-y-1">
                {workout.warnings.map((warning, i) => (
                  <li key={i} className="text-white text-sm">• {warning}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
      
      {/* Action Buttons */}
      <div className="flex gap-4">
        <button
          onClick={onBack}
          className="flex-1 py-4 rounded-xl bg-dark-600 text-white font-display font-semibold hover:bg-dark-500 transition-colors"
        >
          RETOUR
        </button>
        <button
          onClick={() => onComplete({ completedExercises: completedExercises.size, totalExercises })}
          className="flex-1 py-4 rounded-xl bg-gradient-to-r from-ice-500 to-ice-400 text-dark-900 font-display font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
        >
          <Check className="w-5 h-5" />
          TERMINÉ
        </button>
      </div>
    </div>
  );
}

function ExerciseSection({ 
  title, icon, exercises, expanded, onToggle, 
  completedExercises, onToggleExercise, onStartTimer, 
  sectionPrefix, isMain = false 
}) {
  const parseRestTime = (rest) => {
    if (!rest || rest === '-') return null;
    const match = rest.match(/(\d+)/);
    return match ? parseInt(match[1]) : null;
  };
  
  return (
    <div className="glass rounded-2xl overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full p-5 flex items-center gap-3 hover:bg-dark-700/50 transition-colors"
      >
        <div className={`w-10 h-10 rounded-lg ${isMain ? 'bg-ice-gradient' : 'bg-dark-600'} flex items-center justify-center`}>
          {icon}
        </div>
        <span className="font-display text-lg text-white flex-1 text-left">{title}</span>
        <span className="text-gray-400 text-sm mr-2">{exercises.length} exercices</span>
        {expanded ? <ChevronUp className="w-5 h-5 text-gray-400" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
      </button>
      
      {expanded && (
        <div className="px-5 pb-5 space-y-3">
          {exercises.map((exercise, index) => {
            const exerciseId = `${sectionPrefix}-${index}`;
            const isCompleted = completedExercises.has(exerciseId);
            const restSeconds = parseRestTime(exercise.rest);
            
            return (
              <div 
                key={index}
                className={`p-4 rounded-xl border transition-all ${
                  isCompleted 
                    ? 'bg-alert-green/10 border-alert-green/30' 
                    : 'bg-dark-700 border-dark-600'
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => onToggleExercise(exerciseId)}
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all ${
                      isCompleted
                        ? 'bg-alert-green border-alert-green text-dark-900'
                        : 'border-gray-500 hover:border-ice-400'
                    }`}
                  >
                    {isCompleted && <Check className="w-4 h-4" />}
                  </button>
                  
                  <div className="flex-1">
                    <p className={`font-semibold ${isCompleted ? 'text-alert-green line-through' : 'text-white'}`}>
                      {exercise.exercise}
                    </p>
                    
                    <div className="flex flex-wrap gap-2 mt-2">
                      {exercise.sets && (
                        <span className="px-2 py-0.5 bg-dark-600 rounded text-xs text-gray-300">
                          {exercise.sets} séries
                        </span>
                      )}
                      {exercise.reps && (
                        <span className="px-2 py-0.5 bg-dark-600 rounded text-xs text-gray-300">
                          {exercise.reps}
                        </span>
                      )}
                      {exercise.duration && (
                        <span className="px-2 py-0.5 bg-dark-600 rounded text-xs text-gray-300">
                          {exercise.duration}
                        </span>
                      )}
                      {restSeconds && (
                        <button
                          onClick={() => onStartTimer(restSeconds)}
                          className="px-2 py-0.5 bg-ice-500/20 rounded text-xs text-ice-400 hover:bg-ice-500/30 transition-colors"
                        >
                          ⏱️ {exercise.rest}
                        </button>
                      )}
                    </div>
                    
                    {exercise.notes && (
                      <p className="text-sm text-gray-400 mt-2 italic">
                        💡 {exercise.notes}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
