import { useState, useEffect } from 'react';
import { 
  ChevronLeft, Calendar, TrendingUp, Moon, Zap, AlertCircle,
  ChevronDown, ChevronUp
} from 'lucide-react';
import { getCheckInHistory, getWorkoutHistory } from '../lib/storage';
import { format, subDays, isToday, isYesterday } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function History({ onBack }) {
  const [checkIns, setCheckIns] = useState([]);
  const [expandedDay, setExpandedDay] = useState(null);
  
  useEffect(() => {
    const history = getCheckInHistory().sort((a, b) => 
      new Date(b.date) - new Date(a.date)
    );
    setCheckIns(history);
  }, []);
  
  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    if (isToday(date)) return "Aujourd'hui";
    if (isYesterday(date)) return "Hier";
    return format(date, "EEEE d MMMM", { locale: fr });
  };
  
  const getScenarioFromCheckIn = (checkIn) => {
    if (checkIn.pain >= 4) return 'ROUGE';
    if (checkIn.energy < 5 || checkIn.sleep < 5) return 'ORANGE';
    return 'VERT';
  };
  
  const getScenarioColor = (scenario) => {
    switch (scenario) {
      case 'ROUGE': return 'bg-alert-red';
      case 'ORANGE': return 'bg-alert-orange';
      default: return 'bg-alert-green';
    }
  };
  
  // Calculate 7-day trend
  const calculateTrend = () => {
    if (checkIns.length < 2) return null;
    
    const recent = checkIns.slice(0, 7);
    const avgPain = recent.reduce((sum, c) => sum + c.pain, 0) / recent.length;
    const avgEnergy = recent.reduce((sum, c) => sum + c.energy, 0) / recent.length;
    const avgSleep = recent.reduce((sum, c) => sum + c.sleep, 0) / recent.length;
    
    return { avgPain, avgEnergy, avgSleep };
  };
  
  const trend = calculateTrend();
  
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={onBack}
          className="p-2 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-3">
          <Calendar className="w-8 h-8 text-ice-400" />
          <h1 className="font-display text-2xl text-white">Historique</h1>
        </div>
      </div>
      
      {/* Trend Summary */}
      {trend && (
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-ice-400" />
            <span className="text-sm text-gray-400">Moyennes 7 jours</span>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <Moon className="w-5 h-5 text-alert-green mx-auto mb-1" />
              <p className="text-2xl font-display font-bold text-alert-green">
                {trend.avgSleep.toFixed(1)}
              </p>
              <p className="text-xs text-gray-400">Sommeil</p>
            </div>
            <div className="text-center">
              <Zap className="w-5 h-5 text-alert-orange mx-auto mb-1" />
              <p className="text-2xl font-display font-bold text-alert-orange">
                {trend.avgEnergy.toFixed(1)}
              </p>
              <p className="text-xs text-gray-400">Énergie</p>
            </div>
            <div className="text-center">
              <AlertCircle className="w-5 h-5 text-alert-red mx-auto mb-1" />
              <p className="text-2xl font-display font-bold text-alert-red">
                {trend.avgPain.toFixed(1)}
              </p>
              <p className="text-xs text-gray-400">Douleur</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Check-in List */}
      {checkIns.length === 0 ? (
        <div className="glass rounded-2xl p-8 text-center">
          <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Aucun check-in enregistré</p>
          <p className="text-sm text-gray-500 mt-2">Commence par faire ton premier check-in!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {checkIns.map((checkIn, index) => {
            const scenario = getScenarioFromCheckIn(checkIn);
            const isExpanded = expandedDay === checkIn.id;
            
            return (
              <div 
                key={checkIn.id}
                className="glass rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setExpandedDay(isExpanded ? null : checkIn.id)}
                  className="w-full p-4 flex items-center gap-4 hover:bg-dark-700/50 transition-colors"
                >
                  {/* Scenario indicator */}
                  <div className={`w-3 h-12 rounded-full ${getScenarioColor(scenario)}`} />
                  
                  {/* Date */}
                  <div className="flex-1 text-left">
                    <p className="font-semibold text-white capitalize">
                      {formatDate(checkIn.date)}
                    </p>
                    <p className="text-sm text-gray-400">
                      Battle Readiness: {checkIn.battleReadiness || '--'}%
                    </p>
                  </div>
                  
                  {/* Quick stats */}
                  <div className="flex items-center gap-3 text-sm">
                    <span className="text-alert-green">{checkIn.sleep}</span>
                    <span className="text-alert-orange">{checkIn.energy}</span>
                    <span className="text-alert-red">{checkIn.pain}</span>
                  </div>
                  
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400" />
                  )}
                </button>
                
                {/* Expanded details */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-2 border-t border-dark-600">
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div className="bg-dark-700 rounded-lg p-3 text-center">
                        <Moon className="w-4 h-4 text-alert-green mx-auto mb-1" />
                        <p className="text-lg font-bold text-white">{checkIn.sleep}/10</p>
                        <p className="text-xs text-gray-400">Sommeil</p>
                      </div>
                      <div className="bg-dark-700 rounded-lg p-3 text-center">
                        <Zap className="w-4 h-4 text-alert-orange mx-auto mb-1" />
                        <p className="text-lg font-bold text-white">{checkIn.energy}/10</p>
                        <p className="text-xs text-gray-400">Énergie</p>
                      </div>
                      <div className="bg-dark-700 rounded-lg p-3 text-center">
                        <AlertCircle className="w-4 h-4 text-alert-red mx-auto mb-1" />
                        <p className="text-lg font-bold text-white">{checkIn.pain}/10</p>
                        <p className="text-xs text-gray-400">Douleur</p>
                      </div>
                    </div>
                    
                    {checkIn.painZones && checkIn.painZones.length > 0 && (
                      <div className="mb-3">
                        <p className="text-xs text-gray-400 mb-2">Zones douloureuses:</p>
                        <div className="flex flex-wrap gap-1">
                          {checkIn.painZones.map(zone => (
                            <span key={zone} className="px-2 py-1 bg-alert-red/20 text-alert-red text-xs rounded">
                              {zone}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {checkIn.notes && (
                      <div className="bg-dark-700 rounded-lg p-3">
                        <p className="text-xs text-gray-400 mb-1">Notes:</p>
                        <p className="text-sm text-white">{checkIn.notes}</p>
                      </div>
                    )}
                    
                    <div className="mt-3 text-xs text-gray-500">
                      {format(new Date(checkIn.date), "HH:mm", { locale: fr })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
