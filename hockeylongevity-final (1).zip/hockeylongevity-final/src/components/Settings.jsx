import { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, Key, Save, Trash2, Download, Upload,
  ChevronLeft, Check, AlertCircle, Database
} from 'lucide-react';
import { 
  getApiKey, saveApiKey, getSettings, saveSettings,
  exportData, importData, clearAllData, getCheckInHistory,
  getWorkoutHistory, getWeeklyStats
} from '../lib/storage';
import { testApiConnection } from '../lib/api';

export default function Settings({ onBack }) {
  const [apiKey, setApiKey] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiStatus, setApiStatus] = useState(null); // null, 'testing', 'valid', 'invalid'
  const [settings, setLocalSettings] = useState(getSettings());
  const [saved, setSaved] = useState(false);
  const [stats, setStats] = useState(null);
  
  useEffect(() => {
    const key = getApiKey();
    if (key) setApiKey(key);
    
    const weeklyStats = getWeeklyStats();
    const checkIns = getCheckInHistory();
    const workouts = getWorkoutHistory();
    
    setStats({
      totalCheckIns: checkIns.length,
      totalWorkouts: workouts.length,
      weeklyStats
    });
  }, []);
  
  const handleSaveApiKey = async () => {
    setApiStatus('testing');
    const isValid = await testApiConnection(apiKey);
    
    if (isValid) {
      saveApiKey(apiKey);
      setApiStatus('valid');
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } else {
      setApiStatus('invalid');
    }
  };
  
  const handleExport = () => {
    const data = exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hockeylongevity-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  
  const handleImport = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target.result);
        importData(data);
        alert('Données importées avec succès!');
        window.location.reload();
      } catch (err) {
        alert('Erreur: Fichier invalide');
      }
    };
    reader.readAsText(file);
  };
  
  const handleClearData = () => {
    if (confirm('⚠️ Supprimer TOUTES les données? Cette action est irréversible!')) {
      if (confirm('Es-tu vraiment sûr? Tout sera effacé.')) {
        clearAllData();
        window.location.reload();
      }
    }
  };
  
  const toggleSetting = (key) => {
    const newSettings = { ...settings, [key]: !settings[key] };
    setLocalSettings(newSettings);
    saveSettings(newSettings);
  };
  
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={onBack}
          className="p-2 rounded-lg bg-dark-700 hover:bg-dark-600 transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-3">
          <SettingsIcon className="w-8 h-8 text-ice-400" />
          <h1 className="font-display text-2xl text-white">Paramètres</h1>
        </div>
      </div>
      
      {/* API Key Section */}
      <div className="glass rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Key className="w-6 h-6 text-ice-400" />
          <h2 className="font-display text-lg text-white">Clé API Claude (Anthropic)</h2>
        </div>
        
        <p className="text-sm text-gray-400 mb-4">
          Pour activer le coach IA intelligent, entre ta clé API Anthropic. 
          Sans clé, l'app utilise des workouts pré-définis.
        </p>
        
        <div className="space-y-3">
          <div className="relative">
            <input
              type={showApiKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="sk-..."
              className="w-full bg-dark-700 border border-dark-600 rounded-xl p-4 pr-24 text-white placeholder-gray-500 focus:outline-none focus:border-ice-500 transition-colors font-mono text-sm"
            />
            <button
              onClick={() => setShowApiKey(!showApiKey)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white text-sm"
            >
              {showApiKey ? 'Cacher' : 'Voir'}
            </button>
          </div>
          
          <button
            onClick={handleSaveApiKey}
            disabled={!apiKey || apiStatus === 'testing'}
            className="w-full py-3 rounded-xl bg-ice-500 text-dark-900 font-semibold hover:bg-ice-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {apiStatus === 'testing' ? (
              <>
                <div className="spinner w-5 h-5" />
                Test en cours...
              </>
            ) : saved ? (
              <>
                <Check className="w-5 h-5" />
                Sauvegardé!
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                Sauvegarder
              </>
            )}
          </button>
          
          {apiStatus === 'valid' && (
            <div className="flex items-center gap-2 text-alert-green text-sm">
              <Check className="w-4 h-4" />
              Clé API valide et connectée!
            </div>
          )}
          
          {apiStatus === 'invalid' && (
            <div className="flex items-center gap-2 text-alert-red text-sm">
              <AlertCircle className="w-4 h-4" />
              Clé API invalide. Vérifie et réessaie.
            </div>
          )}
        </div>
        
        <div className="mt-4 p-3 bg-dark-700 rounded-lg">
          <p className="text-xs text-gray-400">
            💡 Obtiens ta clé sur <a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener noreferrer" className="text-ice-400 hover:underline">console.anthropic.com</a>
          </p>
        </div>
      </div>
      
      {/* Stats Section */}
      {stats && (
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Database className="w-6 h-6 text-ice-400" />
            <h2 className="font-display text-lg text-white">Tes Données</h2>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-dark-700 rounded-xl p-4 text-center">
              <p className="text-3xl font-display font-bold text-ice-400">{stats.totalCheckIns}</p>
              <p className="text-sm text-gray-400">Check-ins</p>
            </div>
            <div className="bg-dark-700 rounded-xl p-4 text-center">
              <p className="text-3xl font-display font-bold text-alert-green">{stats.totalWorkouts}</p>
              <p className="text-sm text-gray-400">Workouts</p>
            </div>
          </div>
          
          {stats.weeklyStats && (
            <div className="mt-4 p-4 bg-dark-700 rounded-xl">
              <p className="text-sm text-gray-400 mb-2">Moyennes 7 derniers jours:</p>
              <div className="flex justify-between text-sm">
                <span>Sommeil: <strong className="text-alert-green">{stats.weeklyStats.avgSleep}/10</strong></span>
                <span>Énergie: <strong className="text-alert-orange">{stats.weeklyStats.avgEnergy}/10</strong></span>
                <span>Douleur: <strong className="text-alert-red">{stats.weeklyStats.avgPain}/10</strong></span>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* Data Management */}
      <div className="glass rounded-2xl p-6">
        <h2 className="font-display text-lg text-white mb-4">Gestion des données</h2>
        
        <div className="space-y-3">
          <button
            onClick={handleExport}
            className="w-full py-3 rounded-xl bg-dark-600 text-white font-semibold hover:bg-dark-500 transition-colors flex items-center justify-center gap-2"
          >
            <Download className="w-5 h-5" />
            Exporter mes données
          </button>
          
          <label className="w-full py-3 rounded-xl bg-dark-600 text-white font-semibold hover:bg-dark-500 transition-colors flex items-center justify-center gap-2 cursor-pointer">
            <Upload className="w-5 h-5" />
            Importer des données
            <input
              type="file"
              accept=".json"
              onChange={handleImport}
              className="hidden"
            />
          </label>
          
          <button
            onClick={handleClearData}
            className="w-full py-3 rounded-xl bg-alert-red/20 text-alert-red font-semibold hover:bg-alert-red/30 transition-colors flex items-center justify-center gap-2"
          >
            <Trash2 className="w-5 h-5" />
            Effacer toutes les données
          </button>
        </div>
      </div>
      
      {/* App Info */}
      <div className="text-center text-gray-500 text-sm pb-8">
        <p>HockeyLongevity AI v1.0</p>
        <p>Built for Stéphane 🏒</p>
      </div>
    </div>
  );
}
