import { useState } from 'react';
import { Moon, Zap, AlertCircle, ChevronRight, Calendar } from 'lucide-react';
import { getDayContext, calculateBattleReadiness } from '../lib/coachBrain';

const PAIN_ZONES = [
  'Hanche gauche',
  'Hanche droite', 
  'Dos lombaire (L4-L5)',
  'Dos thoracique',
  'Genoux',
  'Épaules'
];

export default function DailyCheckIn({ onSubmit, loading }) {
  const [sleep, setSleep] = useState(5);
  const [energy, setEnergy] = useState(5);
  const [pain, setPain] = useState(3);
  const [painZones, setPainZones] = useState(['Dos lombaire (L4-L5)', 'Hanche gauche', 'Hanche droite']);
  const [workloadYesterday, setWorkloadYesterday] = useState(7);
  const [notes, setNotes] = useState('');
  
  const dayContext = getDayContext();
  const battleReadiness = calculateBattleReadiness({ sleep, energy, pain });
  
  const togglePainZone = (zone) => {
    setPainZones(prev => 
      prev.includes(zone) 
        ? prev.filter(z => z !== zone)
        : [...prev, zone]
    );
  };
  
  const handleSubmit = () => {
    onSubmit({
      sleep,
      energy,
      pain,
      painZones,
      workloadYesterday,
      notes,
      battleReadiness
    });
  };
  
  const getScenarioColor = () => {
    if (pain >= 4) return 'red';
    if (energy < 5 || sleep < 5) return 'orange';
    return 'green';
  };
  
  const scenario = getScenarioColor();
  
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Day Context Banner */}
      <div className={`glass rounded-2xl p-4 ${
        dayContext.isMatchDay ? 'border-ice-500 border-2' : ''
      }`}>
        <div className="flex items-center gap-3">
          <Calendar className={`w-6 h-6 ${dayContext.isMatchDay ? 'text-ice-400' : 'text-gray-400'}`} />
          <div>
            <p className="font-display text-lg text-white">{dayContext.dayName}</p>
            <p className="text-sm text-gray-400">{dayContext.context}</p>
          </div>
          {dayContext.isMatchDay && (
            <span className="ml-auto px-3 py-1 bg-ice-500/20 text-ice-400 rounded-full text-sm font-semibold">
              MATCH
            </span>
          )}
        </div>
      </div>
      
      {/* Battle Readiness Preview */}
      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <span className="text-gray-400 text-sm uppercase tracking-wide">Battle Readiness</span>
          <span className={`text-3xl font-display font-bold ${
            scenario === 'green' ? 'text-alert-green' :
            scenario === 'orange' ? 'text-alert-orange' : 'text-alert-red'
          }`}>
            {battleReadiness}%
          </span>
        </div>
        <div className="h-3 bg-dark-700 rounded-full overflow-hidden">
          <div 
            className={`h-full transition-all duration-500 rounded-full ${
              scenario === 'green' ? 'bg-gradient-to-r from-alert-green to-ice-500' :
              scenario === 'orange' ? 'bg-gradient-to-r from-alert-orange to-yellow-400' :
              'bg-gradient-to-r from-alert-red to-red-400'
            }`}
            style={{ width: `${battleReadiness}%` }}
          />
        </div>
      </div>
      
      {/* Sleep Slider */}
      <div className="glass rounded-2xl p-6 animate-fade-in-up animate-delay-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-green-gradient flex items-center justify-center">
            <Moon className="w-6 h-6 text-alert-green" />
          </div>
          <div className="flex-1">
            <h3 className="font-display text-lg text-white">Qualité du Sommeil</h3>
            <p className="text-sm text-gray-400">Comment as-tu dormi?</p>
          </div>
          <span className="text-3xl font-display font-bold text-alert-green">{sleep}</span>
        </div>
        <input
          type="range"
          min="1"
          max="10"
          value={sleep}
          onChange={(e) => setSleep(parseInt(e.target.value))}
          className="w-full slider-sleep"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>Insomnie</span>
          <span>Réparateur</span>
        </div>
      </div>
      
      {/* Energy Slider */}
      <div className="glass rounded-2xl p-6 animate-fade-in-up animate-delay-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-orange-gradient flex items-center justify-center">
            <Zap className="w-6 h-6 text-alert-orange" />
          </div>
          <div className="flex-1">
            <h3 className="font-display text-lg text-white">Niveau d'Énergie</h3>
            <p className="text-sm text-gray-400">Comment tu te sens?</p>
          </div>
          <span className="text-3xl font-display font-bold text-alert-orange">{energy}</span>
        </div>
        <input
          type="range"
          min="1"
          max="10"
          value={energy}
          onChange={(e) => setEnergy(parseInt(e.target.value))}
          className="w-full slider-energy"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>Épuisé</span>
          <span>En feu 🔥</span>
        </div>
      </div>
      
      {/* Pain Slider */}
      <div className="glass rounded-2xl p-6 animate-fade-in-up animate-delay-300">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-red-gradient flex items-center justify-center">
            <AlertCircle className="w-6 h-6 text-alert-red" />
          </div>
          <div className="flex-1">
            <h3 className="font-display text-lg text-white">Niveau de Douleur</h3>
            <p className="text-sm text-gray-400">Hanches, dos, articulations</p>
          </div>
          <span className="text-3xl font-display font-bold text-alert-red">{pain}</span>
        </div>
        <input
          type="range"
          min="1"
          max="10"
          value={pain}
          onChange={(e) => setPain(parseInt(e.target.value))}
          className="w-full slider-pain"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>Aucune</span>
          <span>Crise aiguë</span>
        </div>
        
        {/* Pain Zones */}
        <div className="mt-4 pt-4 border-t border-dark-600">
          <p className="text-sm text-gray-400 mb-3">Zones douloureuses:</p>
          <div className="flex flex-wrap gap-2">
            {PAIN_ZONES.map(zone => (
              <button
                key={zone}
                onClick={() => togglePainZone(zone)}
                className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                  painZones.includes(zone)
                    ? 'bg-alert-red/20 text-alert-red border border-alert-red/50'
                    : 'bg-dark-700 text-gray-400 border border-dark-600'
                }`}
              >
                {zone}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Work Load Yesterday */}
      <div className="glass rounded-2xl p-6 animate-fade-in-up animate-delay-400">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1">
            <h3 className="font-display text-lg text-white">Charge de travail hier</h3>
            <p className="text-sm text-gray-400">Maçonnerie - intensité de la journée</p>
          </div>
          <span className="text-2xl font-display font-bold text-ice-400">{workloadYesterday}/10</span>
        </div>
        <input
          type="range"
          min="1"
          max="10"
          value={workloadYesterday}
          onChange={(e) => setWorkloadYesterday(parseInt(e.target.value))}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>Journée légère</span>
          <span>Journée de fou</span>
        </div>
      </div>
      
      {/* Notes */}
      <div className="glass rounded-2xl p-6 animate-fade-in-up animate-delay-500">
        <h3 className="font-display text-lg text-white mb-3">Notes (optionnel)</h3>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Ex: Mal dormi à cause du match de hockey à TV..."
          className="w-full bg-dark-700 border border-dark-600 rounded-xl p-4 text-white placeholder-gray-500 resize-none h-24 focus:outline-none focus:border-ice-500 transition-colors"
        />
      </div>
      
      {/* Submit Button */}
      <button
        onClick={handleSubmit}
        disabled={loading}
        className={`w-full py-5 rounded-2xl font-display text-xl font-bold transition-all flex items-center justify-center gap-3 ${
          loading 
            ? 'bg-dark-600 text-gray-400 cursor-not-allowed'
            : scenario === 'green'
              ? 'bg-gradient-to-r from-alert-green to-ice-500 text-white hover:opacity-90 active:scale-[0.98]'
              : scenario === 'orange'
                ? 'bg-gradient-to-r from-alert-orange to-yellow-500 text-dark-900 hover:opacity-90 active:scale-[0.98]'
                : 'bg-gradient-to-r from-alert-red to-red-400 text-white hover:opacity-90 active:scale-[0.98]'
        }`}
      >
        {loading ? (
          <>
            <div className="spinner w-6 h-6" />
            <span>Le coach analyse...</span>
          </>
        ) : (
          <>
            <span>GÉNÉRER MON PLAN</span>
            <ChevronRight className="w-6 h-6" />
          </>
        )}
      </button>
    </div>
  );
}
