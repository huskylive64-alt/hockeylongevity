/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'ice': {
          50: '#e6f9ff',
          100: '#b3edff',
          200: '#80e1ff',
          300: '#4dd5ff',
          400: '#1ac9ff',
          500: '#00bfff',
          600: '#00a3d9',
          700: '#0087b3',
          800: '#006b8c',
          900: '#004f66',
        },
        'dark': {
          900: '#0a0a0f',
          800: '#12121a',
          700: '#1a1a24',
          600: '#22222e',
          500: '#2a2a38',
        },
        'alert': {
          red: '#ff4757',
          orange: '#ffa502',
          green: '#2ed573',
        }
      },
      fontFamily: {
        'display': ['Oswald', 'sans-serif'],
        'body': ['Barlow', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 5px #00bfff, 0 0 10px #00bfff' },
          '100%': { boxShadow: '0 0 20px #00bfff, 0 0 30px #00bfff' },
        }
      }
    },
  },
  plugins: [],
}

